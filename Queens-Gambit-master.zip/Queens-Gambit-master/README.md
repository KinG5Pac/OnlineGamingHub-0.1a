# Queens-Gambit-V2

## Description
A real time multiplayer chess game with chat functionality.

![](https://ks-mindhour.github.io/img/chess2.gif)
